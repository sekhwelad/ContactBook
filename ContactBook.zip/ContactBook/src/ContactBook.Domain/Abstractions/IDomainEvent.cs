﻿using MediatR;

namespace ContactBook.Domain.Abstractions;

public interface IDomainEvent : INotification
{
}