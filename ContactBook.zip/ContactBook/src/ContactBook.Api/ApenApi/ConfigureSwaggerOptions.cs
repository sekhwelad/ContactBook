﻿using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace AddressBook.Api.ApenApi;

public sealed class ConfigureSwaggerOptions : IConfigureNamedOptions<SwaggerGenOptions>
{
    private readonly IApiVersionDescriptionProvider _provider;

    public ConfigureSwaggerOptions(IApiVersionDescriptionProvider provider)
    {
        _provider = provider ?? throw new ArgumentNullException(nameof(provider));
    }
    public void Configure(string? name, SwaggerGenOptions options)
    {
        Configure(options);
    }

    public void Configure(SwaggerGenOptions options)
    {
        if (_provider == null) return;

        foreach (var description in _provider.ApiVersionDescriptions)
        {
            //options.SwaggerDoc(description.GroupName, new OpenApiInfo
            //{
            //    Title = $"ContactBook API {description.ApiVersion}",
            //    Version = description.GroupName.ToString()
            //});
            options.SwaggerDoc(description.GroupName, CreateVersionInfo(description));
        }
    }

    private static OpenApiInfo CreateVersionInfo(ApiVersionDescription apiVersionDescription)
    {
        var openApiInfo = new OpenApiInfo
        {
            Title = $"ContactBook.Api v{apiVersionDescription.ApiVersion}",
           // Version = apiVersionDescription.ApiVersion.ToString()
            Version = "v1"
        };

        if (apiVersionDescription.IsDeprecated)
        {
            openApiInfo.Description += " This API version has been deprecated";
        }

        return openApiInfo;
    }
}
